function Contact() {
  return <div> You Are in the Contact Page</div>;
}

export default Contact;
