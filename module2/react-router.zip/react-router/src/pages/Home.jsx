function Home() {
  return <div> You Are in the Home Page</div>;
}

export default Home;
