function About() {
  return <div> You Are in the About Page</div>;
}

export default About;
