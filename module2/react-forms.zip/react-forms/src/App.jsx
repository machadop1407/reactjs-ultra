import Form from "./components/Form";
import "./App.css";

function App() {
  return (
    <div>
      <Form />
    </div>
  );
}

export default App;
